import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, input, effect, Component } from '@angular/core';
import { shareReplay, map, catchError, throwError } from 'rxjs';
import { HEADLESS_RENDERER_CONFIG, M1PageSchemaValidator, HeadlessRendererError, HeadlessPageRendererComponent } from '@jmgduarte/wp-angular-renderer';
import { DOCUMENT } from '@angular/common';
import { Meta, Title } from '@angular/platform-browser';

class PremiumPageService {
    http = inject(HttpClient);
    config = inject(HEADLESS_RENDERER_CONFIG);
    validator = inject(M1PageSchemaValidator);
    cache = new Map();
    getPage(slug, locale = this.config.defaultLocale) {
        const key = `${locale}:${slug}`;
        const cached = this.cache.get(key);
        if (cached)
            return cached;
        const request = this.fetchPage(slug, locale).pipe(shareReplay({ bufferSize: 1, refCount: false }));
        this.cache.set(key, request);
        return request;
    }
    fetchPage(slug, locale) {
        const base = this.config.apiBaseUrl.replace(/\/+$/, '');
        const encodedSlug = encodeURIComponent(slug.replace(/^\/+/, ''));
        const url = this.config.restRouteMode === 'query'
            ? `${base}/index.php?rest_route=${encodeURIComponent(`/headless-renderer/v1/pages/${encodedSlug}`)}&locale=${encodeURIComponent(locale)}`
            : `${base}/wp-json/headless-renderer/v1/pages/${encodedSlug}?locale=${encodeURIComponent(locale)}`;
        return this.http.get(url).pipe(map((value) => this.validate(value)), catchError((error) => {
            const fallback = this.config.fallbackLocale;
            if (error instanceof HttpErrorResponse && error.status === 404 && fallback && fallback !== locale)
                return this.getPage(slug, fallback);
            return throwError(() => error instanceof HeadlessRendererError ? error : new HeadlessRendererError('PAGE_FETCH_FAILED', 'Premium PageSchema could not be loaded.', error));
        }));
    }
    validate(value) {
        const base = this.validator.validate(value);
        const rawPage = value['page'];
        return { ...base, page: { ...base.page, seo: readSeo(rawPage['seo'], this.config.frontendBaseUrl) } };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumPageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumPageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumPageService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function readSeo(value, frontendBaseUrl) {
    if (!isRecord$1(value))
        return undefined;
    return {
        title: stringValue(value['title']), description: stringValue(value['description']), canonical: publicPageUrl(value['canonical'], frontendBaseUrl),
        robots: isRecord$1(value['robots']) ? { index: booleanValue(value['robots']['index']), follow: booleanValue(value['robots']['follow']) } : undefined,
        openGraph: isRecord$1(value['openGraph']) ? { title: stringValue(value['openGraph']['title']), description: stringValue(value['openGraph']['description']), url: publicPageUrl(value['openGraph']['url'], frontendBaseUrl), type: stringValue(value['openGraph']['type']), image: readImage(value['openGraph']['image']) } : undefined,
        twitter: isRecord$1(value['twitter']) ? { card: readTwitterCard(value['twitter']['card']), title: stringValue(value['twitter']['title']), description: stringValue(value['twitter']['description']), image: readImage(value['twitter']['image']) } : undefined,
    };
}
function publicPageUrl(value, frontendBaseUrl) {
    const source = stringValue(value);
    if (!source || !frontendBaseUrl)
        return source;
    try {
        const sourceUrl = new URL(source);
        const frontendUrl = new URL(frontendBaseUrl);
        frontendUrl.pathname = sourceUrl.pathname;
        frontendUrl.search = sourceUrl.search;
        frontendUrl.hash = sourceUrl.hash;
        return frontendUrl.toString();
    }
    catch {
        return source;
    }
}
function readImage(value) {
    if (!isRecord$1(value) || typeof value['src'] !== 'string' || value['src'] === '')
        return undefined;
    return { src: value['src'], alt: stringValue(value['alt']) };
}
function isRecord$1(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }
function stringValue(value) { return typeof value === 'string' && value !== '' ? value : undefined; }
function booleanValue(value) { return typeof value === 'boolean' ? value : undefined; }
function readTwitterCard(value) { return value === 'summary' || value === 'summary_large_image' ? value : undefined; }

class PremiumNavigationService {
    http = inject(HttpClient);
    config = inject(HEADLESS_RENDERER_CONFIG);
    cache = new Map();
    getMenu(location, locale = this.config.defaultLocale) {
        const key = `${locale}:${location}`;
        const cached = this.cache.get(key);
        if (cached)
            return cached;
        const base = this.config.apiBaseUrl.replace(/\/+$/, '');
        const cleanLocation = encodeURIComponent(location);
        const url = this.config.restRouteMode === 'query'
            ? `${base}/index.php?rest_route=${encodeURIComponent(`/headless-renderer/v1/menus/${cleanLocation}`)}&locale=${encodeURIComponent(locale)}`
            : `${base}/wp-json/headless-renderer/v1/menus/${cleanLocation}?locale=${encodeURIComponent(locale)}`;
        const request = this.http.get(url).pipe(map((value) => validate(value)), catchError((error) => throwError(() => error instanceof HeadlessRendererError ? error : new HeadlessRendererError('MENU_FETCH_FAILED', 'Premium navigation could not be loaded.', error))), shareReplay({ bufferSize: 1, refCount: false }));
        this.cache.set(key, request);
        return request;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumNavigationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumNavigationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumNavigationService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function validate(value) {
    if (!isRecord(value) || value['schemaVersion'] !== '1.0' || typeof value['locale'] !== 'string' || typeof value['location'] !== 'string' || !Array.isArray(value['items']))
        throw new HeadlessRendererError('MENU_INVALID', 'Premium navigation schema is invalid.', value);
    return {
        schemaVersion: '1.0',
        locale: value['locale'],
        location: value['location'],
        menu: isRecord(value['menu'])
            ? {
                ariaLabel: typeof value['menu']['ariaLabel'] === 'string' ? value['menu']['ariaLabel'] : 'Navigation',
                orientation: value['menu']['orientation'] === 'vertical' ? 'vertical' : 'horizontal',
            }
            : { ariaLabel: 'Navigation', orientation: 'horizontal' },
        items: value['items'].filter(isNavigationItem),
    };
}
function isNavigationItem(value) { return isRecord(value) && typeof value['id'] === 'string' && typeof value['label'] === 'string' && typeof value['link'] === 'object' && value['link'] !== null; }
function isRecord(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }

class PremiumSeoMetadataService {
    document = inject(DOCUMENT);
    meta = inject(Meta);
    title = inject(Title);
    managed = new Set();
    apply(metadata, fallbackTitle) {
        this.removeManaged();
        const title = metadata?.title || fallbackTitle;
        if (title)
            this.title.setTitle(title);
        if (metadata?.description)
            this.setName('description', metadata.description);
        if (metadata?.canonical)
            this.setCanonical(metadata.canonical);
        if (metadata?.robots) {
            this.setName('robots', `${metadata.robots.index === false ? 'noindex' : 'index'},${metadata.robots.follow === false ? 'nofollow' : 'follow'}`);
        }
        const openGraph = metadata?.openGraph;
        if (openGraph) {
            this.setProperty('og:title', openGraph.title);
            this.setProperty('og:description', openGraph.description);
            this.setProperty('og:url', openGraph.url);
            this.setProperty('og:type', openGraph.type);
            this.setProperty('og:image', openGraph.image?.src);
        }
        const twitter = metadata?.twitter;
        if (twitter) {
            this.setName('twitter:card', twitter.card);
            this.setName('twitter:title', twitter.title);
            this.setName('twitter:description', twitter.description);
            this.setName('twitter:image', twitter.image?.src);
        }
    }
    setName(name, content) {
        if (!content)
            return;
        this.meta.updateTag({ name, content });
        this.managed.add(`name|${name}`);
    }
    setProperty(property, content) {
        if (!content)
            return;
        this.meta.updateTag({ property, content });
        this.managed.add(`property|${property}`);
    }
    setCanonical(url) {
        let link = this.document.head.querySelector('link[rel="canonical"]');
        if (!link) {
            link = this.document.createElement('link');
            link.rel = 'canonical';
            this.document.head.appendChild(link);
        }
        link.href = url;
        this.managed.add('canonical');
    }
    removeManaged() {
        for (const key of this.managed) {
            if (key === 'canonical')
                this.document.head.querySelector('link[rel="canonical"]')?.remove();
            else {
                const [attribute, value] = key.split('|');
                this.meta.removeTag(`${attribute}="${value}"`);
            }
        }
        this.managed.clear();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumSeoMetadataService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumSeoMetadataService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumSeoMetadataService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class PremiumPageRendererComponent {
    schema = input.required(...(ngDevMode ? [{ debugName: "schema" }] : /* istanbul ignore next */ []));
    titleFormatter = input(...(ngDevMode ? [undefined, { debugName: "titleFormatter" }] : /* istanbul ignore next */ []));
    seo = inject(PremiumSeoMetadataService);
    constructor() {
        effect(() => {
            const schema = this.schema();
            const title = schema.page.seo?.title ?? schema.page.title;
            const formattedTitle = this.titleFormatter()?.(title) ?? title;
            this.seo.apply(schema.page.seo ? { ...schema.page.seo, title: formattedTitle } : undefined, formattedTitle);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumPageRendererComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.22", type: PremiumPageRendererComponent, isStandalone: true, selector: "headless-premium-page-renderer", inputs: { schema: { classPropertyName: "schema", publicName: "schema", isSignal: true, isRequired: true, transformFunction: null }, titleFormatter: { classPropertyName: "titleFormatter", publicName: "titleFormatter", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: '<headless-page-renderer [schema]="schema()" />', isInline: true, dependencies: [{ kind: "component", type: HeadlessPageRendererComponent, selector: "headless-page-renderer", inputs: ["schema"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.22", ngImport: i0, type: PremiumPageRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'headless-premium-page-renderer',
                    imports: [HeadlessPageRendererComponent],
                    template: '<headless-page-renderer [schema]="schema()" />',
                }]
        }], ctorParameters: () => [], propDecorators: { schema: [{ type: i0.Input, args: [{ isSignal: true, alias: "schema", required: true }] }], titleFormatter: [{ type: i0.Input, args: [{ isSignal: true, alias: "titleFormatter", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { PremiumNavigationService, PremiumPageRendererComponent, PremiumPageService, PremiumSeoMetadataService };
//# sourceMappingURL=jmgduarte-wp-angular-renderer-premium.mjs.map
