import { Observable } from 'rxjs';
import { NavigationSchema, PageSchema } from '@jmgduarte/wp-angular-renderer';
import * as i0 from '@angular/core';

interface PremiumSeoMetadata {
    title?: string;
    description?: string;
    canonical?: string;
    robots?: {
        index?: boolean;
        follow?: boolean;
    };
    openGraph?: {
        title?: string;
        description?: string;
        canonical?: string;
        url?: string;
        type?: string;
        image?: {
            src: string;
            alt?: string;
        };
    };
    twitter?: {
        card?: 'summary' | 'summary_large_image';
        title?: string;
        description?: string;
        image?: {
            src: string;
            alt?: string;
        };
    };
}

interface PremiumPageSchema extends PageSchema {
    page: PageSchema['page'] & {
        seo?: PremiumSeoMetadata;
    };
}
interface PremiumNavigationSchema extends NavigationSchema {
    locale: string;
}

declare class PremiumPageService {
    private readonly http;
    private readonly config;
    private readonly validator;
    private readonly cache;
    getPage(slug: string, locale?: string): Observable<PremiumPageSchema>;
    private fetchPage;
    private validate;
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumPageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PremiumPageService>;
}

declare class PremiumNavigationService {
    private readonly http;
    private readonly config;
    private readonly cache;
    getMenu(location: string, locale?: string): Observable<PremiumNavigationSchema>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumNavigationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PremiumNavigationService>;
}

declare class PremiumPageRendererComponent {
    readonly schema: i0.InputSignal<PremiumPageSchema>;
    readonly titleFormatter: i0.InputSignal<((title: string) => string) | undefined>;
    private readonly seo;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumPageRendererComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PremiumPageRendererComponent, "headless-premium-page-renderer", never, { "schema": { "alias": "schema"; "required": true; "isSignal": true; }; "titleFormatter": { "alias": "titleFormatter"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class PremiumSeoMetadataService {
    private readonly document;
    private readonly meta;
    private readonly title;
    private readonly managed;
    apply(metadata: PremiumSeoMetadata | undefined, fallbackTitle?: string): void;
    private setName;
    private setProperty;
    private setCanonical;
    private removeManaged;
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumSeoMetadataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PremiumSeoMetadataService>;
}

export { PremiumNavigationService, PremiumPageRendererComponent, PremiumPageService, PremiumSeoMetadataService };
export type { PremiumNavigationSchema, PremiumPageSchema, PremiumSeoMetadata };
