# Renderer Premium

This package contains premium capabilities that depend on `@jmgduarte/wp-angular-renderer`.

## M5 — SEO and Localization

The premium package provides locale-aware page and menu services, SEO metadata application, localized request caching, and the `headless-premium-page-renderer` wrapper. The free renderer remains independent and contains the base page/block rendering APIs.

```ts
import {
  PremiumPageService,
  PremiumNavigationService,
  PremiumPageRendererComponent,
} from '@jmgduarte/wp-angular-renderer-premium';
```

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 21.2.0.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the library, run:

```bash
ng build renderer
```

This command will compile your project, and the build artifacts will be placed in the `dist/` directory.

### Publishing the Library

Once the project is built, you can publish your library by following these steps:

1. Navigate to the `dist` directory:

   ```bash
   cd dist/renderer
   ```

2. Run the `npm publish` command to publish your library to the npm registry:
   ```bash
   npm publish
   ```

## Running unit tests

To execute unit tests with the [Karma](https://karma-runner.github.io) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

The consuming Angular application can override renderer-wide CSS tokens from its global stylesheet with `headless-page-renderer .headless-page { ... }`. For Gutenberg widths, override `--wp--style--global--content-size` (default `645px`) and `--wp--style--global--wide-size` (default `1340px`). `align: none` uses the content size, `align: wide` uses the wide size, and `align: full` removes the width limit and spans the renderer root. Root padding can be overridden with `--wp--style--root--padding-left` and `--wp--style--root--padding-right`.

```scss
headless-page-renderer .headless-page {
  --wp--style--global--content-size: 500px;
  --wp--style--global--wide-size: 1200px;
}
```

Styles authored by an individual WordPress block are emitted inline and take precedence over those global defaults.

### Featured Cards Tokens

When WordPress does not provide card-specific styles, `featured-cards` uses the existing `--wp--preset--...` tokens and component-specific tokens with fallbacks. A consuming application can override individual values without replacing the component stylesheet:

```scss
headless-page-renderer .headless-page {
  --wp--preset--featured-cards--card-background: #ffffff;
  --wp--preset--featured-cards--card-border-radius: 12px;
  --wp--preset--featured-cards--title-font-size: var(--wp--preset--font-size--x-large);
  --wp--preset--featured-cards--tag-background: #eaf5f5;
  --wp--preset--featured-cards--content-font-size: var(--wp--preset--font-size--large);
}
```

The available component tokens cover the grid gap, card background/border/shadow/padding, media size and colors, icon size/color, title typography, tag typography/spacing, and content typography. Existing WordPress color, font, and spacing presets are used as fallbacks where their semantics match.

Responsive Gutenberg values are preserved as `mobile`, `tablet`, and `desktop` entries in the block style properties. The renderer applies mobile as the base rule, tablet at `min-width: 782px`, and desktop at `min-width: 1024px`. For example, a WordPress-authored `fontSize` value with three entries is rendered with the matching value at each viewport range.

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
